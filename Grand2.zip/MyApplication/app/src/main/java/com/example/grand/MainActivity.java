package com.example.grand;

import android.arch.lifecycle.Observer;
import android.content.Context;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.DisplayMetrics;
import android.util.Log;

import com.example.grand.Adapters.InsuranceAdapter;
import com.example.grand.Model.DoctorEntryModel;
import com.example.grand.Model.InsuranceEntryModel;
import com.example.grand.R;
import com.example.grand.Util.AppHelper;
import com.example.grand.ViewModel.DoctorsViewModel;
import com.example.grand.ViewModel.InsuranceViewModel;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MainActivity extends AppCompatActivity {

    @BindView(R.id.recycler)
    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ButterKnife.bind(this);
        AppHelper appHelper = new AppHelper();
        appHelper.actionBar(this, "Insurance", getSupportActionBar());

        putDataIntoRecyclerView();
    }

    private void putDataIntoRecyclerView() {

        InsuranceViewModel insuranceViewModel = new InsuranceViewModel(getApplication());
        insuranceViewModel.getAllInsurance().observe(MainActivity.this, new Observer<List<InsuranceEntryModel>>() {
            @Override
            public void onChanged(@Nullable List<InsuranceEntryModel> insuranceEntryModels) {

                recyclerView.setLayoutManager(new GridLayoutManager(MainActivity.this,
                        calculateNoOfColumns(MainActivity.this)));

                recyclerView.setAdapter(new InsuranceAdapter(MainActivity.this, insuranceEntryModels));
            }
        });
    }

    public static int calculateNoOfColumns(Context context) {
        DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
        float dpWidth = displayMetrics.widthPixels / displayMetrics.density;
        int scalingFactor = 300;
        int noOfColumns = (int) (dpWidth / scalingFactor);
        if (noOfColumns < 2)
            noOfColumns = 2;
        return noOfColumns;
    }
}
