package com.example.grand.Model;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.ForeignKey;
import android.arch.persistence.room.Ignore;
import android.arch.persistence.room.PrimaryKey;
import android.support.annotation.NonNull;

@Entity(tableName = "doctor_table")
public class DoctorEntryModel {

    @PrimaryKey(autoGenerate = true)
    int id;

    @ForeignKey(entity = InsuranceEntryModel.class, parentColumns = "id", childColumns = "insuranceId")
    int insuranceId;

    String name;
    int rating;

    @Ignore
    public DoctorEntryModel(int insuranceId, @NonNull String name, int rating) {

        this.insuranceId = insuranceId;
        this.name = name;
        this.rating = rating;
    }

    public DoctorEntryModel(int id) {

        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getInsuranceId() {
        return insuranceId;
    }

    public void setInsuranceId(int insuranceId) {
        this.insuranceId = insuranceId;
    }

    @NonNull
    public String getName() {
        return name;
    }

    public void setName(@NonNull String name) {
        this.name = name;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }
}
