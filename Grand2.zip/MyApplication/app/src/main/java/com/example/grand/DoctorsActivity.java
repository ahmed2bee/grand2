package com.example.grand;

import android.annotation.TargetApi;
import android.arch.lifecycle.Observer;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.daimajia.slider.library.SliderLayout;
import com.daimajia.slider.library.SliderTypes.BaseSliderView;
import com.daimajia.slider.library.SliderTypes.TextSliderView;
import com.daimajia.slider.library.Tricks.ViewPagerEx;
import com.example.grand.Adapters.InsuranceAdapter;
import com.example.grand.Model.DoctorEntryModel;
import com.example.grand.Model.MassageEntryModel;
import com.example.grand.Util.AppHelper;
import com.example.grand.ViewModel.DoctorsViewModel;
import com.example.grand.ViewModel.MessagesViewModel;

import java.util.HashMap;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class DoctorsActivity extends AppCompatActivity {

    private int insuranceID, doctorId;
    private boolean flag = true;
    public static String DOCTOR_ID;

    @BindView(R.id.sliderLayout)
    SliderLayout sliderLayout;

    @BindView(R.id.message_body)
    EditText msg;

    @BindView(R.id.send_btn)
    Button sendBtn;

    @BindView(R.id.start_chat)
    Button startChatBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctors);

        ButterKnife.bind(this);
        AppHelper appHelper = new AppHelper();
        appHelper.actionBar(this, getIntent().getStringExtra(InsuranceAdapter.INSURANCE_NAME) + " Doctors", getSupportActionBar());
        insuranceID = getIntent().getIntExtra(InsuranceAdapter.INSURANCE_ID, 0);
        setupSlider();

        // Send msg to doc
        sendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                sendMessageToDoctor(doctorId);
            }
        });

        startChatBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(DoctorsActivity.this, StartChatActivity.class);
                i.putExtra(DOCTOR_ID, doctorId);
                startActivity(i);
            }
        });
    }

    private void setupSlider() {

        DoctorsViewModel doctorsViewModel = new DoctorsViewModel(getApplication(), insuranceID);
        doctorsViewModel.getAllDoctors().observe(DoctorsActivity.this, new Observer<List<DoctorEntryModel>>() {
            @TargetApi(Build.VERSION_CODES.M)
            @Override
            public void onChanged(@Nullable final List<DoctorEntryModel> doctorEntryModels) {

                HashMap<String, Integer> sliderImages = new HashMap<>();

                for (int i = 0; i < doctorEntryModels.size(); i++) {

                    sliderImages.put(doctorEntryModels.get(i).getName(), R.drawable.doc);

                    // Putting inital value to get the doc id
                    if (flag) {
                        doctorId = doctorEntryModels.get(i).getId();
                        Log.e("werwqew1", doctorId + " <<<");
                        flag = false;
                    }
                }

                for (String name : sliderImages.keySet()) {

                    TextSliderView textSliderView = new TextSliderView(DoctorsActivity.this);
                    textSliderView
                            .description(name)
                            .image(sliderImages.get(name))
                            .setScaleType(BaseSliderView.ScaleType.FitCenterCrop);
                    sliderLayout.stopAutoCycle();
                    sliderLayout.addSlider(textSliderView);
                }
                sliderLayout.addOnPageChangeListener(new ViewPagerEx.OnPageChangeListener() {
                    @Override
                    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

                    }

                    @Override
                    public void onPageSelected(int position) {

                        doctorId = doctorEntryModels.get(position).getId();
                        Log.e("werwqew2", doctorId + " <<<");
                    }

                    @Override
                    public void onPageScrollStateChanged(int state) {

                    }
                });
            }
        });
    }

    private void sendMessageToDoctor(int doctorId) {

        MessagesViewModel messagesViewModel = new MessagesViewModel(getApplication(), doctorId);
        messagesViewModel.insertMsg(new MassageEntryModel(doctorId, msg.getText().toString()));
        msg.getText().clear();
        Toast.makeText(this, "Message Sent !", Toast.LENGTH_SHORT).show();
    }
}






























