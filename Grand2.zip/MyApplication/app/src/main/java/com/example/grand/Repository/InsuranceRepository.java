package com.example.grand.Repository;

import android.app.Application;
import android.arch.lifecycle.LiveData;

import com.example.grand.Database.AppDatabase;
import com.example.grand.Database.DAO;
import com.example.grand.Model.InsuranceEntryModel;
import com.example.grand.Util.AppExecutors;

import java.util.List;

public class InsuranceRepository {

    private AppDatabase database;
    private DAO dao;
    private LiveData<List<InsuranceEntryModel>> allInsurence;

    public InsuranceRepository(Application application){

        database = AppDatabase.getInstance(application);
        dao = database.dao();
        allInsurence = dao.selectInsurance();
    }

    public LiveData<List<InsuranceEntryModel>> getAllInsurence(){

        return allInsurence;
    }

    public void addInsurence(final InsuranceEntryModel insuranceEntryModel){

        AppExecutors.getInstance().diskIO().execute(new Runnable() {
            @Override
            public void run() {

                database.dao().insertInsurance(insuranceEntryModel);
            }
        });
    }
}

























