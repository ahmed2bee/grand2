package com.example.grand.Repository;

import android.app.Application;
import android.arch.lifecycle.LiveData;

import com.example.grand.Database.AppDatabase;
import com.example.grand.Database.DAO;
import com.example.grand.Model.DoctorEntryModel;
import com.example.grand.Util.AppExecutors;

import java.util.List;

public class DoctorRepository {

    private AppDatabase database;
    private DAO dao;
    private LiveData<List<DoctorEntryModel>> allDoctors;

    public DoctorRepository(Application application, int insuranceId){

        database = AppDatabase.getInstance(application);
        dao = database.dao();
        allDoctors = dao.selectDoctors(insuranceId);
    }

    public LiveData<List<DoctorEntryModel>> getAllDoctors(){

        return allDoctors;
    }

    public void insertDoctor(final DoctorEntryModel doctorEntryModel){

        AppExecutors.getInstance().diskIO().execute(new Runnable() {
            @Override
            public void run() {

                database.dao().insertDoctor(doctorEntryModel);
            }
        });
    }
}
