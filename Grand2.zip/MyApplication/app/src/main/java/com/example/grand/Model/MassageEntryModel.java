package com.example.grand.Model;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.ForeignKey;
import android.arch.persistence.room.Ignore;
import android.arch.persistence.room.PrimaryKey;
import android.support.annotation.NonNull;

@Entity(tableName = "massage_table")
public class MassageEntryModel {

    @PrimaryKey(autoGenerate = true)
    int id;

    @ForeignKey(entity = DoctorEntryModel.class, parentColumns = "id", childColumns = "doctorId")
    int doctorId;

    @NonNull
    String msgBody;

    @Ignore
    public MassageEntryModel(int doctorId, @NonNull String msgBody) {
        this.doctorId = doctorId;
        this.msgBody = msgBody;
    }

    public MassageEntryModel(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(int doctorId) {
        this.doctorId = doctorId;
    }

    @NonNull
    public String getMsgBody() {
        return msgBody;
    }

    public void setMsgBody(@NonNull String msgBody) {
        this.msgBody = msgBody;
    }
}
