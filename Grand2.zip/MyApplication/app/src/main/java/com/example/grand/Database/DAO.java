package com.example.grand.Database;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

import com.example.grand.Model.DoctorEntryModel;
import com.example.grand.Model.InsuranceEntryModel;
import com.example.grand.Model.MassageEntryModel;

import java.util.List;

@Dao
public interface DAO {

    @Insert
    void insertInsurance(InsuranceEntryModel insuranceEntryModel);

    @Insert
    void insertDoctor(DoctorEntryModel doctorEntryModel);

    @Insert
    void insertMessage(MassageEntryModel massageEntryModel);

    @Query("SELECT * FROM insurance_table")
    LiveData<List<InsuranceEntryModel>> selectInsurance();

    @Query("SELECT * FROM doctor_table WHERE insuranceId = :insuranceId")
    LiveData<List<DoctorEntryModel>> selectDoctors(int insuranceId);

    @Query("SELECT * FROM massage_table WHERE doctorId = :docId")
    LiveData<List<MassageEntryModel>> selectMassages(int docId);
}
