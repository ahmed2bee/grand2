package com.example.grand.Adapters;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.grand.DoctorsActivity;
import com.example.grand.Model.InsuranceEntryModel;
import com.example.grand.R;
import com.squareup.picasso.Picasso;

import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class InsuranceAdapter extends RecyclerView.Adapter<InsuranceAdapter.MyHolder> {

    Context context;
    List<InsuranceEntryModel> list;
    public static String INSURANCE_ID = "insuranceID";
    public static String INSURANCE_NAME = "insuranceName";

    public InsuranceAdapter(Context context, List<InsuranceEntryModel> list) {
        this.context = context;
        this.list = list;
    }

    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        InsuranceAdapter.MyHolder myHolder = new InsuranceAdapter.MyHolder(LayoutInflater.from(context).inflate(
                R.layout.recycler_view_row, viewGroup, false));
        return myHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder myHolder, final int i) {

        Picasso.with(context).load(list.get(i).getImage()).into(myHolder.img);
        myHolder.insuranceName.setText(list.get(i).getName());

        myHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(context, DoctorsActivity.class);
                intent.putExtra(INSURANCE_ID, list.get(i).getId());
                intent.putExtra(INSURANCE_NAME, list.get(i).getName());
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class MyHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.insurance_name)
        TextView insuranceName;

        @BindView(R.id.img)
        ImageView img;

        public MyHolder(@NonNull View itemView) {
            super(itemView);

            ButterKnife.bind(this, itemView);
        }
    }
}
