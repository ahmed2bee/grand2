package com.example.grand.ViewModel;

import android.app.Application;
import android.arch.lifecycle.LiveData;

import com.example.grand.Model.DoctorEntryModel;
import com.example.grand.Model.MassageEntryModel;
import com.example.grand.Repository.DoctorRepository;
import com.example.grand.Repository.MassageRepository;

import java.util.List;

public class MessagesViewModel {

    private LiveData<List<MassageEntryModel>> allMassages;
    private MassageRepository repository;

    public MessagesViewModel(Application application, int docId){

        repository = new MassageRepository(application, docId);
        allMassages = repository.getAllMessages();
    }

    public LiveData<List<MassageEntryModel>> getAllMessages(){ return allMassages; }
    public void insertMsg(MassageEntryModel massageEntryModel){ repository.insertMsg(massageEntryModel);}
}
