package com.example.grand.Repository;

import android.app.Application;
import android.arch.lifecycle.LiveData;

import com.example.grand.Database.AppDatabase;
import com.example.grand.Database.DAO;
import com.example.grand.Model.DoctorEntryModel;
import com.example.grand.Model.MassageEntryModel;
import com.example.grand.Util.AppExecutors;

import java.util.List;

public class MassageRepository {

    private AppDatabase database;
    private DAO dao;
    private LiveData<List<MassageEntryModel>> allMessages;

    public MassageRepository(Application application, int doctorId){

        database = AppDatabase.getInstance(application);
        dao = database.dao();
        allMessages = dao.selectMassages(doctorId);
    }

    public LiveData<List<MassageEntryModel>> getAllMessages(){

        return allMessages;
    }

    public void insertMsg(final MassageEntryModel MassageEntryModel){

        AppExecutors.getInstance().diskIO().execute(new Runnable() {
            @Override
            public void run() {

                database.dao().insertMessage(MassageEntryModel);
            }
        });
    }
}
