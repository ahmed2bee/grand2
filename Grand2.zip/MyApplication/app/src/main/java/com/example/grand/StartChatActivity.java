package com.example.grand;

import android.arch.lifecycle.Observer;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import com.example.grand.Adapters.StartChatAdapter;
import com.example.grand.Model.MassageEntryModel;
import com.example.grand.Util.AppHelper;
import com.example.grand.ViewModel.MessagesViewModel;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class StartChatActivity extends AppCompatActivity {

    private int doctorId;

    @BindView(R.id.recycler)
    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start_chat);

        ButterKnife.bind(this);
        AppHelper appHelper = new AppHelper();
        appHelper.actionBar(this, "Doctor Chat", getSupportActionBar());
        doctorId = getIntent().getIntExtra(DoctorsActivity.DOCTOR_ID, 0);

        getAllmessages(doctorId);
    }

    private void getAllmessages(int doctorId) {

        MessagesViewModel messagesViewModel = new MessagesViewModel(getApplication(), doctorId);
        messagesViewModel.getAllMessages().observe(StartChatActivity.this, new Observer<List<MassageEntryModel>>() {
            @Override
            public void onChanged(@Nullable List<MassageEntryModel> massageEntryModels) {

                recyclerView.setLayoutManager(new LinearLayoutManager(StartChatActivity.this));
                recyclerView.setAdapter(new StartChatAdapter(StartChatActivity.this, massageEntryModels));
            }
        });
    }
}
