package com.example.grand.Database;

import android.arch.persistence.db.SupportSQLiteDatabase;
import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Context;
import android.support.annotation.NonNull;
import android.util.Log;

import com.example.grand.Model.DoctorEntryModel;
import com.example.grand.Model.InsuranceEntryModel;
import com.example.grand.Model.MassageEntryModel;
import com.example.grand.R;
import com.example.grand.Util.AppExecutors;

import java.util.ArrayList;
import java.util.Arrays;

@Database(entities = {InsuranceEntryModel.class, DoctorEntryModel.class, MassageEntryModel.class},
        version = 1, exportSchema = false)

public abstract class AppDatabase extends RoomDatabase {

    private static final String LOG_TAG = AppDatabase.class.getSimpleName();
    private static final Object LOCK = new Object();
    private static final String DATABASE_NAME = "db_grand";
    private static AppDatabase sInstance;

    public static AppDatabase getInstance(Context context) {
        if (sInstance == null) {
            synchronized (LOCK) {
                Log.d(LOG_TAG, "Creating new database instance");
                sInstance = Room.databaseBuilder(context.getApplicationContext(),
                        AppDatabase.class, AppDatabase.DATABASE_NAME)
                        .addCallback(sRoomDatabaseCallback)
                        .build();
            }
        }
        Log.d(LOG_TAG, "Getting the database instance");
        return sInstance;
    }

    public abstract DAO dao();

    private static Callback sRoomDatabaseCallback =
            new Callback() {

                @Override
                public void onCreate(@NonNull SupportSQLiteDatabase db) {
                    super.onCreate(db);

                    AppExecutors.getInstance().diskIO().execute(new Runnable() {
                        @Override
                        public void run() {

                            AppExecutors.getInstance().diskIO().execute(new Runnable() {
                                @Override
                                public void run() {

                                    DAO dao = sInstance.dao();

                                    // Insert Data into DB onOpen
                                    putDataIntoInsuranceTable(dao);
                                    putDataIntoDoctorsTable(dao);
                                }
                            });
                        }
                    });
                }
            };

    public static void putDataIntoInsuranceTable(DAO dao) {

        InsuranceEntryModel insurance;

        ArrayList<Integer> imageInsuranceArray = new ArrayList<>(
                Arrays.asList(R.drawable.puba, R.drawable.medgulf, R.drawable.insured, R.drawable.insuranceimg));

        ArrayList<String> insuranceArray = new ArrayList<>(
                Arrays.asList("BUPA", "MEDGULF", "INSURED", "CUA"));

        for (int i = 0; i < insuranceArray.size(); i++) {
            insurance = new InsuranceEntryModel(insuranceArray.get(i), imageInsuranceArray.get(i));
            dao.insertInsurance(insurance);
        }
    }

    public static void putDataIntoDoctorsTable(DAO dao) {

        DoctorEntryModel doctors;

        ArrayList<String> doctorsNames = new ArrayList<>(
                Arrays.asList("Karim Sobhy", "Ahmed Ibrahim", "Hala Mostafa", "Abdulla Eid",
                        "Mahmoud Gamal", "Mohamed Ibrahim", "Yassin Badr", "Mostafa Essam"));

        ArrayList<Integer> insuranceIds = new ArrayList<>(Arrays.asList(1, 1, 2, 2, 3, 3, 4, 4));
        ArrayList<Integer> ratings = new ArrayList<>(Arrays.asList(4, 5, 3, 2, 5, 1, 3, 4));


        for (int i = 0; i < doctorsNames.size(); i++) {
            doctors = new DoctorEntryModel(insuranceIds.get(i), doctorsNames.get(i), ratings.get(i));
            dao.insertDoctor(doctors);
        }
    }
}























