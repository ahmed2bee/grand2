package com.example.grand.Model;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.Ignore;
import android.arch.persistence.room.PrimaryKey;
import android.support.annotation.NonNull;

@Entity(tableName = "insurance_table")
public class InsuranceEntryModel {

    @PrimaryKey(autoGenerate = true)
    int id;

    @NonNull
    String name;

    @NonNull
    int image;

    @Ignore
    public InsuranceEntryModel(String name, int images) { this.name = name; this.image = images;}

    public InsuranceEntryModel(int id) {
        this.id = id;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
