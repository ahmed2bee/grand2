package com.example.grand.ViewModel;

import android.app.Application;
import android.arch.lifecycle.LiveData;

import com.example.grand.Model.DoctorEntryModel;
import com.example.grand.Model.InsuranceEntryModel;
import com.example.grand.Repository.DoctorRepository;
import com.example.grand.Repository.InsuranceRepository;

import java.util.List;

public class DoctorsViewModel {

    private LiveData<List<DoctorEntryModel>> allDoctors;
    private DoctorRepository repository;

    public DoctorsViewModel(Application application, int insuranceId){

        repository = new DoctorRepository(application, insuranceId);
        allDoctors = repository.getAllDoctors();
    }

    public LiveData<List<DoctorEntryModel>> getAllDoctors(){ return allDoctors; }
    public void insertDoctor(DoctorEntryModel doctorEntryModel){ repository.insertDoctor(doctorEntryModel);}
}
