package com.example.grand.Util;

import android.content.Context;
import android.graphics.Color;
import android.support.v7.app.ActionBar;
import android.view.Gravity;
import android.widget.TextView;

import com.example.grand.R;

public class AppHelper {

    public void actionBar(Context context, String title, ActionBar actionBar) {

        TextView view = new TextView(context);
        view.setText(title);
        view.setWidth(1000);
        view.setTextSize(30f);
        view.setTextColor(Color.WHITE);
        view.setGravity(Gravity.CENTER_HORIZONTAL);
        actionBar.setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        actionBar.setCustomView(view);
    }
}