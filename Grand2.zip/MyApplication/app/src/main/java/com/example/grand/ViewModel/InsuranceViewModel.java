package com.example.grand.ViewModel;

import android.app.Application;
import android.arch.lifecycle.LiveData;

import com.example.grand.Model.InsuranceEntryModel;
import com.example.grand.Repository.InsuranceRepository;

import java.util.List;

public class InsuranceViewModel {

    private LiveData<List<InsuranceEntryModel>> allInsurance;
    private InsuranceRepository repository;

    public InsuranceViewModel(Application application){

        repository = new InsuranceRepository(application);
        allInsurance = repository.getAllInsurence();
    }

    public LiveData<List<InsuranceEntryModel>> getAllInsurance(){ return allInsurance; }
    public void insertInsurance(InsuranceEntryModel insuranceEntryModel){ repository.addInsurence(insuranceEntryModel);}
}
